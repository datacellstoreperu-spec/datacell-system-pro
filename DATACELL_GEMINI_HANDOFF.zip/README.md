# DATACELL → GEMINI HANDOFF (ZIP)
Generado: 2026-02-06T00:30:26

## Contenido
- DIRECTIVAS_JUANITA.md  → reglas de trabajo y contexto para que Gemini actúe como Juanita
- App.jsx                → código React (lo recibido en este chat)
- REPOSITORIO_RESUMEN.md → cómo usar este chat como base de datos viva (precios/proveedores/historial)
- CONTEXTO_JSON.json     → resumen estructurado para importarlo a otro LLM
- README.md              → este archivo

## Nota importante
En este chat, algunos **adjuntos previos pueden estar expirados** (el sistema lo reporta). Este ZIP incluye lo que está disponible en el historial visible + el código que pegaste.
Si necesitas incluir imágenes/adjuntos antiguos, vuelve a subirlos y se agregan al ZIP en otra exportación.
