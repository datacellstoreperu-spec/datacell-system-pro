# REPOSITORIO (CHAT) — DATACELL STORE PERÚ

Este chat se usa como **repositorio permanente** para:
- Cotizar repuestos y registrar precios (originales y genéricos).
- Mantener listas (RMB, USD, PEN) y costos de importación.
- Guardar proveedores, contactos, históricos de compra, comparativas (original vs genérico vs JCID).
- Registrar decisiones finales de compra.
- Mantener base de datos de precios de la competencia en Perú para estrategias.

## Reglas de registro
Cada nueva cotización debe guardar como mínimo:
1) Producto exacto (modelo, compatibilidad, calidad)
2) Precio (moneda), MOQ, condiciones
3) Proveedor (nombre, contacto, canal)
4) Fecha y vigencia
5) Observaciones (riesgos, garantía, diferencias)

## Flujo de taller (realista)
- Clientes dejan equipos y recogen a 2 días: usar estados OT, diagnóstico, adelantos, y cierre.
- Diagnóstico S/50 opcional, descontable si aprueban reparación.
- Declaración jurada + firma digital.
- Captura de acceso: PIN alfanumérico o patrón; autoriza backup; recomendado NO guardar credenciales.

## Admin
- Admin puede borrar movimientos/OS/items inventario con confirmación.
- Cambiar PIN admin.
